REACT ROUTER


1. svg tag
2. import {Link,NavLink} from 'react-router-dom'
3. import {useLocation} from 'react-router-dom'
4. <Link to="/" className="hover:underline">
                                        Home
                                    </Link>
                                    <Link to="/about" className="hover:underline">
5. GO THROUGH GITHUB FILE
6. go through USER file
7. go through LaYOUT FILE
8.  go through main.jsx file
https://youtu.be/XGUjvIn1Icg?si=v3TrDNajhPyBNWZS
https://youtu.be/VJov5QWEKE4?si=NCPbuf9BYZuHjJoX
 
9.  to use router in application we use routerprovider from react-router-dom
10.  export default function About() 

                    